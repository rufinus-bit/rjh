import { useState } from 'react';
import { Send } from 'lucide-react';

interface QuoteFormProps {
  detailed?: boolean;
  selectedFurnace?: string;
}

export default function QuoteForm({ detailed = false, selectedFurnace = '' }: QuoteFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    furnaceType: selectedFurnace,
    message: '',
    projectDetails: '',
    quantity: '',
    timeline: '',
    budgetRange: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    try {
      const res = await fetch(`${supabaseUrl}/rest/v1/quote_requests`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': supabaseKey,
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          furnace_type: formData.furnaceType,
          message: formData.message,
          project_details: formData.projectDetails,
          quantity: formData.quantity,
          timeline: formData.timeline,
          budget_range: formData.budgetRange,
        }),
      });

      if (res.ok) {
        alert('Thank you for your quote request! We will contact you within 24 hours.');
        setFormData({
          name: '',
          email: '',
          phone: '',
          furnaceType: '',
          message: '',
          projectDetails: '',
          quantity: '',
          timeline: '',
          budgetRange: ''
        });
      } else {
        const error = await res.json();
        console.error('Supabase error:', error);
        alert('Something went wrong. Please try again or contact us directly.');
      }
    } catch (err) {
      console.error('Network error:', err);
      alert('Network error. Please check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Full Name *
          </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            placeholder="John Doe"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Email Address *
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            placeholder="john@company.com"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Phone Number *
          </label>
          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            placeholder="+91 95008 93151"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Furnace Type of Interest *
          </label>
          <select
            name="furnaceType"
            value={formData.furnaceType}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          >
            <option value="">Select a furnace type</option>
            <option value="induction">Induction Melting Furnace</option>
            <option value="arc">Electric Arc Furnace</option>
            <option value="rotary">Rotary Kiln Furnace</option>
            <option value="reverberatory">Reverberatory Furnace</option>
            <option value="crucible">Crucible Furnace</option>
            <option value="muffle">Muffle Furnace</option>
            <option value="tube">Tube Furnace</option>
            <option value="box">Box Furnace</option>
            <option value="annealing">Annealing Furnace</option>
            <option value="tempering">Tempering Furnace</option>
            <option value="vacuum">Vacuum Furnace</option>
            <option value="conveyor">Conveyor Furnace</option>
          </select>
        </div>
      </div>

      {detailed && (
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Quantity Needed
            </label>
            <input
              type="text"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="e.g., 1 unit, 5 units"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Project Timeline
            </label>
            <select
              name="timeline"
              value={formData.timeline}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="">Select timeline</option>
              <option value="urgent">Urgent (1-2 weeks)</option>
              <option value="1month">Within 1 month</option>
              <option value="3months">1-3 months</option>
              <option value="6months">3-6 months</option>
              <option value="flexible">Flexible</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Budget Range
            </label>
            <select
              name="budgetRange"
              value={formData.budgetRange}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="">Select budget range</option>
              <option value="under50k">Under $50,000</option>
              <option value="50k-100k">$50,000 - $100,000</option>
              <option value="100k-250k">$100,000 - $250,000</option>
              <option value="250k-500k">$250,000 - $500,000</option>
              <option value="over500k">Over $500,000</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Project Details
            </label>
            <textarea
              name="projectDetails"
              value={formData.projectDetails}
              onChange={handleChange}
              rows={4}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="Please describe your project requirements, specifications, or any special considerations..."
            />
          </div>
        </div>
      )}

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          {detailed ? 'Additional Message' : 'Message *'}
        </label>
        <textarea
          name="message"
          value={formData.message}
          onChange={handleChange}
          required={!detailed}
          rows={4}
          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          placeholder="Tell us about your furnace requirements..."
        />
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-orange-600 text-white px-8 py-4 rounded-lg hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2 text-lg font-semibold disabled:opacity-60 disabled:cursor-not-allowed"
      >
        <span>{isSubmitting ? 'Submitting...' : 'Submit Quote Request'}</span>
        <Send className="w-5 h-5" />
      </button>
    </form>
  );
}
