interface HeaderProps {
  currentPage: 'home' | 'catalog';
  onNavigate: (page: 'home' | 'catalog') => void;
}

export default function Header({ currentPage, onNavigate }: HeaderProps) {
  return (
    <header className="bg-slate-900 text-white shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src="/logo.png" alt="RJH Logo" className="w-16 h-16 object-contain" />
            <div>
              <h1 className="text-3xl font-bold tracking-tight">RJ HEAT TECH SERVICES</h1>
              <p className="text-sm text-slate-300">Industrial Furnace Solutions</p>
            </div>
          </div>

          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => onNavigate('home')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentPage === 'home'
                  ? 'bg-orange-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onNavigate('catalog')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentPage === 'catalog'
                  ? 'bg-orange-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              Complete Catalog
            </button>
          </nav>
        </div>

        <nav className="md:hidden mt-4 flex space-x-4">
          <button
            onClick={() => onNavigate('home')}
            className={`flex-1 px-4 py-2 rounded-lg transition-colors ${
              currentPage === 'home'
                ? 'bg-orange-600 text-white'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onNavigate('catalog')}
            className={`flex-1 px-4 py-2 rounded-lg transition-colors ${
              currentPage === 'catalog'
                ? 'bg-orange-600 text-white'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            Catalog
          </button>
        </nav>
      </div>
    </header>
  );
}
