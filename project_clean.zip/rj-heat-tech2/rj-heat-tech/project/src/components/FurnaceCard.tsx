import { ArrowRight } from 'lucide-react';

interface FurnaceCardProps {
  name: string;
  type: string;
  image: string;
  specifications?: string[];
  onGetQuote: () => void;
  detailed?: boolean;
}

export default function FurnaceCard({
  name,
  type,
  image,
  specifications,
  onGetQuote,
  detailed = false
}: FurnaceCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col h-full">
      <div className="relative h-64 bg-gradient-to-br from-slate-200 to-slate-300 overflow-hidden group">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center p-8">
            <div className="text-6xl mb-2">{image}</div>
            <p className="text-sm text-slate-600 font-medium">{name}</p>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>

      <div className="p-6 flex-1 flex flex-col">
        <h3 className="text-xl font-bold text-slate-900 mb-2">{name}</h3>
        <p className="text-orange-600 font-semibold mb-4">{type}</p>

        {detailed && specifications && (
          <div className="mb-4 flex-1">
            <h4 className="font-semibold text-slate-700 mb-2">Specifications:</h4>
            <ul className="space-y-1 text-sm text-slate-600">
              {specifications.map((spec, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  <span>{spec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <button
          onClick={onGetQuote}
          className="w-full bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2 mt-auto"
        >
          <span>Get Quote</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
