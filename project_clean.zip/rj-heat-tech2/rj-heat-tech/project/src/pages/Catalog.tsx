import { useState } from 'react';
import { Filter } from 'lucide-react';
import FurnaceCard from '../components/FurnaceCard';
import QuoteForm from '../components/QuoteForm';

export default function Catalog() {
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const [selectedFurnace, setSelectedFurnace] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');

  const allFurnaces = [
    {
      name: 'Induction Melting Furnace',
      type: 'High-Frequency Induction',
      category: 'melting',
      image: '🔥',
      specifications: [
        'Capacity: 50kg - 5000kg',
        'Frequency: 250Hz - 8000Hz',
        'Power: 100kW - 2000kW',
        'Temperature: Up to 1800°C',
        'Energy-efficient IGBT technology',
        'PLC control system with touchscreen'
      ]
    },
    {
      name: 'Electric Arc Furnace',
      type: 'Industrial Steel Making',
      category: 'melting',
      image: '⚡',
      specifications: [
        'Capacity: 5 - 150 tons',
        'Power: 10 - 150 MVA',
        'Temperature: Up to 3500°C',
        'Automated electrode control',
        'Fume extraction system included',
        'Rapid melting capabilities'
      ]
    },
    {
      name: 'Rotary Kiln Furnace',
      type: 'Continuous Processing',
      category: 'industrial',
      image: '🌀',
      specifications: [
        'Length: 10m - 80m',
        'Diameter: 1m - 5m',
        'Temperature: Up to 1400°C',
        'Continuous operation design',
        'Variable speed drive',
        'Multiple heating zones'
      ]
    },
    {
      name: 'Reverberatory Furnace',
      type: 'Aluminum & Non-Ferrous',
      category: 'melting',
      image: '🏭',
      specifications: [
        'Capacity: 500kg - 10 tons',
        'Temperature: Up to 1200°C',
        'Gas or oil fired',
        'High thermal efficiency',
        'Tilting mechanism available',
        'Low maintenance design'
      ]
    },
    {
      name: 'Crucible Furnace',
      type: 'Precision Melting',
      category: 'melting',
      image: '⚗️',
      specifications: [
        'Capacity: 10kg - 500kg',
        'Temperature: Up to 1600°C',
        'Electric or gas heated',
        'Graphite or ceramic crucible',
        'Rapid heat-up time',
        'Ideal for precious metals'
      ]
    },
    {
      name: 'Muffle Furnace',
      type: 'Laboratory & Industrial',
      category: 'heat-treatment',
      image: '🔬',
      specifications: [
        'Chamber size: 5L - 500L',
        'Temperature: Up to 1800°C',
        'Uniform temperature distribution',
        'Programmable controller',
        'Multiple heating elements',
        'Fiber insulation for efficiency'
      ]
    },
    {
      name: 'Tube Furnace',
      type: 'High-Temperature Processing',
      category: 'heat-treatment',
      image: '🧪',
      specifications: [
        'Tube diameter: 25mm - 300mm',
        'Length: 300mm - 3000mm',
        'Temperature: Up to 1700°C',
        'Horizontal or vertical configuration',
        'Gas atmosphere control',
        'Multi-zone heating available'
      ]
    },
    {
      name: 'Box Furnace',
      type: 'Batch Heat Treatment',
      category: 'heat-treatment',
      image: '📦',
      specifications: [
        'Chamber size: 100L - 2000L',
        'Temperature: Up to 1400°C',
        'Front or top loading',
        'Programmable ramp/soak cycles',
        'Over-temperature protection',
        'Heavy-duty construction'
      ]
    },
    {
      name: 'Annealing Furnace',
      type: 'Stress Relief & Softening',
      category: 'heat-treatment',
      image: '🔄',
      specifications: [
        'Batch or continuous operation',
        'Temperature: Up to 1100°C',
        'Controlled atmosphere capability',
        'Uniform heating zones',
        'Energy-efficient design',
        'Automated process control'
      ]
    },
    {
      name: 'Tempering Furnace',
      type: 'Hardness Control',
      category: 'heat-treatment',
      image: '💪',
      specifications: [
        'Temperature: 150°C - 700°C',
        'Precise temperature control ±3°C',
        'Forced air circulation',
        'Multiple tray configuration',
        'Quick heat-up capability',
        'Batch processing optimized'
      ]
    },
    {
      name: 'Vacuum Furnace',
      type: 'Advanced Heat Treatment',
      category: 'specialized',
      image: '💫',
      specifications: [
        'Chamber size: 100L - 5000L',
        'Temperature: Up to 2200°C',
        'Vacuum level: 10⁻⁵ mbar',
        'Gas quenching system',
        'Graphite heating elements',
        'Clean, oxide-free processing'
      ]
    },
    {
      name: 'Conveyor Furnace',
      type: 'Continuous Production',
      category: 'industrial',
      image: '🚊',
      specifications: [
        'Belt width: 300mm - 2000mm',
        'Length: Customizable',
        'Temperature: Up to 1200°C',
        'Variable speed control',
        'Multiple heating zones',
        'High throughput capacity'
      ]
    }
  ];

  const filteredFurnaces = filterCategory === 'all'
    ? allFurnaces
    : allFurnaces.filter(f => f.category === filterCategory);

  const handleGetQuote = (furnaceName: string) => {
    setSelectedFurnace(furnaceName);
    setShowQuoteForm(true);
    setTimeout(() => {
      document.getElementById('detailed-quote-section')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-orange-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-5xl font-bold mb-4">Complete Furnace Catalog</h2>
            <p className="text-xl text-slate-200">
              Browse our comprehensive range of industrial furnaces designed for every application
            </p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between mb-8 bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <Filter className="w-5 h-5 text-orange-600" />
              <span className="font-semibold text-slate-900">Filter by Category:</span>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => setFilterCategory('all')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  filterCategory === 'all'
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Furnaces
              </button>
              <button
                onClick={() => setFilterCategory('melting')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  filterCategory === 'melting'
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Melting
              </button>
              <button
                onClick={() => setFilterCategory('heat-treatment')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  filterCategory === 'heat-treatment'
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Heat Treatment
              </button>
              <button
                onClick={() => setFilterCategory('industrial')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  filterCategory === 'industrial'
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Industrial
              </button>
              <button
                onClick={() => setFilterCategory('specialized')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  filterCategory === 'specialized'
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Specialized
              </button>
            </div>
          </div>

          <div className="mb-6 text-center">
            <p className="text-slate-600">
              Showing <span className="font-bold text-orange-600">{filteredFurnaces.length}</span> {filterCategory === 'all' ? 'furnace models' : `${filterCategory} furnaces`}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredFurnaces.map((furnace) => (
              <FurnaceCard
                key={furnace.name}
                name={furnace.name}
                type={furnace.type}
                image={furnace.image}
                specifications={furnace.specifications}
                onGetQuote={() => handleGetQuote(furnace.name)}
                detailed={true}
              />
            ))}
          </div>
        </div>
      </section>

      <section id="detailed-quote-section" className="py-16 bg-gradient-to-br from-slate-100 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-900 mb-4">Request a Detailed Quote</h2>
              <p className="text-lg text-slate-600">
                Provide comprehensive project details for an accurate quote. Our engineering team will analyze your requirements and respond with a customized solution.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <QuoteForm detailed={true} selectedFurnace={selectedFurnace} />
            </div>

            <div className="mt-12 grid md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <div className="text-4xl mb-3">⏱️</div>
                <h3 className="font-bold text-slate-900 mb-2">Fast Response</h3>
                <p className="text-sm text-slate-600">Initial quote within 24 hours</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <div className="text-4xl mb-3">🎯</div>
                <h3 className="font-bold text-slate-900 mb-2">Custom Solutions</h3>
                <p className="text-sm text-slate-600">Tailored to your specifications</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <div className="text-4xl mb-3">🤝</div>
                <h3 className="font-bold text-slate-900 mb-2">Expert Consultation</h3>
                <p className="text-sm text-slate-600">Free technical support included</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
