import { useState } from 'react';
import { Award, Shield, Users, Zap } from 'lucide-react';
import FurnaceCard from '../components/FurnaceCard';
import QuoteForm from '../components/QuoteForm';

interface HomeProps {
  onNavigate: (page: 'home' | 'catalog') => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const [selectedFurnace, setSelectedFurnace] = useState('');

  const featuredFurnaces = [
    {
      name: 'Induction Melting Furnace',
      type: 'High-Frequency Induction',
      image: '🔥'
    },
    {
      name: 'Electric Arc Furnace',
      type: 'Industrial Steel Making',
      image: '⚡'
    },
    {
      name: 'Rotary Kiln Furnace',
      type: 'Continuous Processing',
      image: '🌀'
    },
    {
      name: 'Vacuum Furnace',
      type: 'Advanced Heat Treatment',
      image: '💫'
    },
    {
      name: 'Muffle Furnace',
      type: 'Laboratory & Industrial',
      image: '🔬'
    },
    {
      name: 'Box Furnace',
      type: 'Batch Heat Treatment',
      image: '📦'
    }
  ];

  const handleGetQuote = (furnaceName: string) => {
    setSelectedFurnace(furnaceName);
    setShowQuoteForm(true);
    setTimeout(() => {
      document.getElementById('quote-section')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-orange-900 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-5xl font-bold mb-6">
              Precision-Engineered Industrial Furnaces
            </h2>
            <p className="text-xl text-slate-200 mb-8">
              Manufacturers and Services Providers for all Types of Heat Treatment Furnaces and allied equipment
            </p>
            <button
              onClick={() => setShowQuoteForm(true)}
              className="bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-orange-700 transition-colors inline-block"
            >
              Request a Custom Quote Today
            </button>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">35+ Years Experience</h3>
              <p className="text-slate-600 text-sm">Industry-leading expertise</p>
            </div>

            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">500+ Clients</h3>
              <p className="text-slate-600 text-sm">Trusted worldwide</p>
            </div>
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">24/7 Support</h3>
              <p className="text-slate-600 text-sm">Always here to help</p>
            </div>
          </div>

          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-6">About Our Furnaces</h2>
            <div className="text-lg text-slate-700 leading-relaxed">
              <p>
                RJ HEAT TECH SERVICES manufactures high-performance industrial furnaces built for reliability and precision. From melting and heat treatment to laboratory applications, our furnaces are engineered with premium materials and advanced controls — delivering energy efficiency, long service life, and full technical support.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-4">Featured Furnaces</h2>
          <p className="text-center text-slate-600 mb-12 max-w-2xl mx-auto">
            Explore our most popular industrial furnace solutions, trusted by leading manufacturers worldwide
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredFurnaces.map((furnace) => (
              <FurnaceCard
                key={furnace.name}
                name={furnace.name}
                type={furnace.type}
                image={furnace.image}
                onGetQuote={() => handleGetQuote(furnace.name)}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => onNavigate('catalog')}
              className="bg-slate-900 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-slate-800 transition-colors inline-block"
            >
              View Complete Catalog
            </button>
          </div>
        </div>
      </section>

      <section id="quote-section" className="py-16 bg-gradient-to-br from-slate-100 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-slate-900 mb-4">Request a Custom Quote</h2>
              <p className="text-lg text-slate-600">
                Get a personalized quote tailored to your specific requirements. Our team will respond within 24 hours.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <QuoteForm selectedFurnace={selectedFurnace} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
