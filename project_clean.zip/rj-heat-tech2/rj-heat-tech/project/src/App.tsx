import { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Catalog from './pages/Catalog';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'catalog'>('home');

  const handleNavigate = (page: 'home' | 'catalog') => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />

      {currentPage === 'home' ? (
        <Home onNavigate={handleNavigate} />
      ) : (
        <Catalog />
      )}

      <Footer />
    </div>
  );
}

export default App;
